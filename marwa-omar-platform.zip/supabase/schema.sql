-- Marwa Omar platform schema for Supabase (PostgreSQL)
create extension if not exists pgcrypto;

create type public.app_role as enum ('teacher','parent');
create type public.attendance_status as enum ('present','late','absent','excused');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role public.app_role not null default 'parent',
  created_at timestamptz not null default now()
);

create table public.groups (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  stage text not null,
  subject text not null default 'رياضيات',
  created_at timestamptz not null default now()
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  student_code text unique not null,
  group_id uuid references public.groups(id) on delete set null,
  parent_user_id uuid references auth.users(id) on delete set null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.assessments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  kind text not null check (kind in ('شامل','كويز','واجب','امتحان شهري','أخرى')),
  max_score numeric(7,2) not null default 100 check (max_score > 0),
  group_id uuid references public.groups(id) on delete cascade,
  held_on date not null default current_date,
  created_at timestamptz not null default now()
);

create table public.grades (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid not null references public.assessments(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  score numeric(7,2) not null check (score >= 0),
  note text,
  created_at timestamptz not null default now(),
  unique (assessment_id, student_id)
);

create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  group_id uuid references public.groups(id) on delete set null,
  attendance_date date not null default current_date,
  status public.attendance_status not null,
  arrived_at timestamptz,
  entry_code_used boolean not null default false,
  note text,
  created_at timestamptz not null default now(),
  unique (student_id, group_id, attendance_date)
);

create table public.resources (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  kind text not null check (kind in ('مذكرة','واجب','حل','إعلان','أخرى')),
  url text not null,
  group_id uuid references public.groups(id) on delete cascade,
  due_at timestamptz,
  published boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.entry_codes (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  code_hash text not null,
  expires_at timestamptz,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.teacher_notes (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  teacher_id uuid not null references auth.users(id) on delete cascade,
  note text not null,
  visible_to_parent boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.groups enable row level security;
alter table public.students enable row level security;
alter table public.assessments enable row level security;
alter table public.grades enable row level security;
alter table public.attendance enable row level security;
alter table public.resources enable row level security;
alter table public.entry_codes enable row level security;
alter table public.teacher_notes enable row level security;

create or replace function public.is_teacher()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles where id = auth.uid() and role = 'teacher'); $$;

create or replace function public.parent_owns_student(sid uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.students where id = sid and parent_user_id = auth.uid()); $$;

create policy "profile self read" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_teacher());
create policy "profile self update" on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid());

create policy "groups visible" on public.groups for select to authenticated using (true);
create policy "teacher manage groups" on public.groups for all to authenticated
using (public.is_teacher()) with check (public.is_teacher());

create policy "students teacher or own parent" on public.students for select to authenticated
using (public.is_teacher() or parent_user_id = auth.uid());
create policy "teacher manage students" on public.students for all to authenticated
using (public.is_teacher()) with check (public.is_teacher());

create policy "assessments visible to relevant users" on public.assessments for select to authenticated
using (public.is_teacher() or exists(select 1 from public.students s where s.group_id = assessments.group_id and s.parent_user_id = auth.uid()));
create policy "teacher manage assessments" on public.assessments for all to authenticated
using (public.is_teacher()) with check (public.is_teacher());

create policy "grades own child or teacher" on public.grades for select to authenticated
using (public.is_teacher() or public.parent_owns_student(student_id));
create policy "teacher manage grades" on public.grades for all to authenticated
using (public.is_teacher()) with check (public.is_teacher());

create policy "attendance own child or teacher" on public.attendance for select to authenticated
using (public.is_teacher() or public.parent_owns_student(student_id));
create policy "teacher manage attendance" on public.attendance for all to authenticated
using (public.is_teacher()) with check (public.is_teacher());

create policy "resources relevant" on public.resources for select to authenticated
using (public.is_teacher() or group_id is null or exists(select 1 from public.students s where s.group_id = resources.group_id and s.parent_user_id = auth.uid()));
create policy "teacher manage resources" on public.resources for all to authenticated
using (public.is_teacher()) with check (public.is_teacher());

create policy "teacher manage entry codes" on public.entry_codes for all to authenticated
using (public.is_teacher()) with check (public.is_teacher());
create policy "teacher manage notes" on public.teacher_notes for all to authenticated
using (public.is_teacher()) with check (public.is_teacher());
create policy "parent read visible notes" on public.teacher_notes for select to authenticated
using (visible_to_parent and public.parent_owns_student(student_id));

-- IMPORTANT: create teacher accounts through Supabase Auth, then set their role using
-- the SQL editor as project owner. Never allow users to self-promote to teacher.
-- Example: update public.profiles set role='teacher' where id='AUTH_USER_UUID';
-- Create profiles via a trusted admin workflow or add a secure auth.users trigger.
